import { Component, OnInit } from '@angular/core';
import { TrainingService } from 'src/app/services/training-service';


@Component({
    selector: 'user-completed-training',
    templateUrl: './ucompleted-training.component.html'
})
export class UcompletedTrainingComponent implements OnInit{

    public completedTrainingList;
userId : number;
userId1 : number = 13;
    constructor (private trainingService : TrainingService){

    }
    ngOnInit(): void {
      this.getUserCompletedTrainingList(this.userId1);
    }
  
    getUserCompletedTrainingList(userId : number) {
        this.trainingService.getUserCompletedTrainingList(userId).subscribe(
        data => { this.completedTrainingList = data},
        err =>console.log(this.completedTrainingList),
        
         );
        
            
            }
}