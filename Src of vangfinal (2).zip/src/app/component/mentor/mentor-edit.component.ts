import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { MentorService } from 'src/app/services/mentor-service';


@Component({
    selector: 'mentor-edit',
    templateUrl: './mentor-edit.component.html'
})
export class MentorEditComponent implements OnInit{
    @ViewChild('f', {  }) updateForm: NgForm;
    mentorEditStatus:boolean = false;


      constructor(private router : Router , private mentorService : MentorService) {

    }

      onSubmit() {
      this.mentorEditStatus = true;
       this.mentorService. updateMentor(this.updateForm.value).subscribe();
       if(this.mentorEditStatus = true ) {
        this.router.navigate(['/mentor-menu']);
       }
      
      }
      
    ngOnInit(): void {
      
    }
  
}