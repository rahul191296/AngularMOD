import { Component, OnInit } from '@angular/core';
import { TrainingService } from 'src/app/services/training-service';


@Component({
    selector: 'user-mentor-search',
    templateUrl: './user-mentor-search.component.html'
})
export class UserMentorSearch implements OnInit{

    technology :  String;

    

    public mentor;
    constructor(private trainingService : TrainingService){
      
         }

onClick(){
  this.getSearch(this.technology);
 
}
getSearch(technology :  String) {
  
  this.trainingService.getSearchList(technology).subscribe(
  data => { this.mentor = data},
  err =>console.log(this.mentor),
  
   );
  
      }
    ngOnInit(): void {
      
    }
  
}
    
