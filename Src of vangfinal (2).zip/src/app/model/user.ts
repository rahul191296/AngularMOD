export class User {
   userId : number;
    name: string;
    email: string;
    password: string;
    contactNo: string;
    dob: string;
    userStatus : string;
}