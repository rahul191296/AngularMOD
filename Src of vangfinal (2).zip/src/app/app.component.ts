import { Component, OnInit } from '@angular/core';
import { LoginStatusService } from './login-status-service';
import { SignUpStatusService } from './signUp-status-service';
import { ITech } from './filterList';
import { TrainingService } from './services/training-service';
import { Mentor } from './model/mentor';




@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

  title = 'Welcomeapp';
  
  userLoginStatus:boolean = false;
  adminLoginStatus:boolean = false;
  mentorLoginStatus:boolean = false;
  technology :  String;

    

     public mentor;
   
  
constructor(private loginStatusService : LoginStatusService ,
   private signUpStatusService : SignUpStatusService ,
   private trainingService : TrainingService){
 
    }
onClick(){
  this.getSearch(this.technology);
 
}
getSearch(technology :  String) {
  
  this.trainingService.getSearchList(technology).subscribe(
  data => { this.mentor = data},
  err =>console.log(this.mentor),
  
   );
  
      }


 
  fromLogin() {
    this.userLoginStatus = this.loginStatusService.getUserLoginStatus();
    this.adminLoginStatus = this.loginStatusService.getAdminLoginStatus();
    this.mentorLoginStatus = this.loginStatusService.getMentorLoginStatus();
   
  }

 
 
 
   
   
 


}
