import { Injectable} from '@angular/core';
import { HttpClient, HttpHeaders  } from '@angular/common/http';





const httpOptions = {
    headers : new HttpHeaders({ 'content-type' : 'application/json'})
       }

       
@Injectable({
    providedIn: 'root'
  })
export class TrainingService {
       
        constructor(private http : HttpClient){
        }
      
        getUserCurrentTrainingList(userId : number) {
         
            return this.http.get('/server4/training/userCurrent/' + userId );
        }

        getMentorCurrentTrainingList(mentorId : number) {
         
          return this.http.get('/server4/training/mentorCurrent/' + mentorId );
      }
      
      getUserCompletedTrainingList(userId : number) {
         
        return this.http.get('/server4/training/userCompleted/' + userId );
    }
    getMentorCompletedTrainingList(mentorId : number) {
         
      return this.http.get('/server4/training/mentorCompleted/' + mentorId );
  }
 
  getSearchList( technology :  String) {
         
    return this.http.get('/server1/user/mentorSearch2/' + technology );
}

      }



