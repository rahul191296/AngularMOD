import { Injectable} from '@angular/core';
import { HttpClient, HttpHeaders  } from '@angular/common/http';





const httpOptions = {
    headers : new HttpHeaders({ 'content-type' : 'application/json'})
       }

       
@Injectable({
    providedIn: 'root'
  })
export class TrainingService {
       
        constructor(private http : HttpClient){
        }
      
        getUserCurrentTrainingList(userId : number) {
         
            return this.http.get('/server/training/userCurrent/' + userId );
        }

        getMentorCurrentTrainingList(mentorId : number) {
         
          return this.http.get('/server/training/mentorCurrent/' + mentorId );
      }
      
      getUserCompletedTrainingList(userId : number) {
         
        return this.http.get('/server/training/userCompleted/' + userId );
    }
    getMentorCompletedTrainingList(mentorId : number) {
         
      return this.http.get('/server/training/mentorCompleted/' + mentorId );
  }
 
      }



