import { Injectable} from '@angular/core';
import { HttpClient, HttpHeaders  } from '@angular/common/http';





const httpOptions = {
    headers : new HttpHeaders({ 'content-type' : 'application/json'})
       }

       
@Injectable({
    providedIn: 'root'
  })
export class MentorService {
       
        constructor(private http : HttpClient){
      
        }
        
        getMentorHistory(mentorId : number) {
         
          return this.http.get('/server/mentor/viewHistory/' + mentorId );
      }
    }