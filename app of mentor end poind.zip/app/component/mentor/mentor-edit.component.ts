import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';


@Component({
    selector: 'mentor-edit',
    templateUrl: './mentor-edit.component.html'
})
export class MentorEditComponent implements OnInit{
    @ViewChild('f', {  }) updateForm: NgForm;
    mentorEditStatus:boolean = false;

    mentor = {
        fullName : '',
        timing : '',
        technologies : '',
        facility : '',
        email : '',
        linkedUrl : '',
        qualification : '',
        experience : '',
        password : '',
       
      };

      constructor(private router : Router ) {

    }

      onSubmit() {
    /*   this.mentor. fullName =  this.signUpForm.value.name;
       this.mentor. timing =  this.signUpForm.value.timing;
       this.mentor. technologies =  this.signUpForm.value.technologies;
       this.mentor. facility = this.signUpForm.value.facility;
       this.mentor. email =  this.signUpForm.value.email;
       this.mentor. linkedUrl =  this.signUpForm.value.linkedUrl;
       this.mentor. qualification =  this.signUpForm.value.qualification;
       this.mentor. experience =  this.signUpForm.value. experience;
       this.mentor. password =  this.signUpForm.value.password;  */

       this.mentorEditStatus = false;
       if(this.mentorEditStatus = true ) {
        this.router.navigate(['/mentor-edit']);
       }
      
    
     
     
      }
      
    ngOnInit(): void {
      
    }
  
}