import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'user-completed-training',
    templateUrl: './ucompleted-training.component.html'
})
export class UcompletedTrainingComponent implements OnInit{
    ngOnInit(): void {
      
    }
  
}