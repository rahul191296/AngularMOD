import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FooterComponent } from './component/footer/footer.component';
import { WelcomeComponent } from './component/home/welcome.component';
import { UserLoginComponent } from './component/user/user-login.component';
import { MentorLoginComponent } from './component/mentor/mentor-login.component';
import { AdminLoginComponent } from './component/admin/admin-login.component';
import { UserRegisterComponent } from './component/user/user-register.component';
import { MentorRegisterComponent } from './component/mentor/mentor-register.component';
import { UcompletedTrainingComponent } from './component/training/user-training/ucompleted-training.component';
import { UcurrentTrainingComponent } from './component/training/user-training/ucurrent-training.component';
import { McurrentTrainingComponent } from './component/training/mentor-training/mcurrent-training.component';
import { McompletedTrainingComponent } from './component/training/mentor-training/mcompleted-training.component';
import { UserMenuComponent } from './component/user/user-menu.component';
import { MentorMenuComponent } from './component/mentor/mentor-menu.component';
import { AdminMenuComponent } from './component/admin/admin-menu.component';








@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    WelcomeComponent,
    UserLoginComponent,
    MentorLoginComponent,
    AdminLoginComponent,
    UserRegisterComponent,
    MentorRegisterComponent,

    UcompletedTrainingComponent,
    UcurrentTrainingComponent,
    McompletedTrainingComponent,
    McurrentTrainingComponent,

    UserMenuComponent,
    MentorMenuComponent,
    AdminMenuComponent
],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    
    
 RouterModule.forRoot([
 
  { path: 'admin-login', component: AdminLoginComponent },
  { path: 'mentor-login', component: MentorLoginComponent },
 { path: 'user-login', component: UserLoginComponent },

  { path: 'mentor-register', component: MentorRegisterComponent },
 { path: 'user-register', component: UserRegisterComponent },

 { path: 'user-menu', component: UserMenuComponent , children : [
   { path: 'user-completed-tr' , component: UcompletedTrainingComponent},
   { path: 'user-current-tr' , component: UcurrentTrainingComponent}
                ]
              },
 { path: 'mentor-menu', component: MentorMenuComponent , children : [
   { path: 'mentor-completed-tr' , component: McompletedTrainingComponent},
   { path: 'mentor-current-tr' , component: McurrentTrainingComponent}
               ]
             },
 { path: 'admin-menu', component: AdminMenuComponent }, 


{ path: 'mentor-completed-tr' , component: McompletedTrainingComponent},
{ path: 'mentor-current-tr' , component: McurrentTrainingComponent},

 { path: '**', redirectTo: 'welcome', pathMatch: 'full' },
 { path: '', redirectTo: 'welcome', pathMatch: 'full' }
  
]),
   
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
