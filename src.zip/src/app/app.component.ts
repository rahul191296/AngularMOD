import { Component, OnInit } from '@angular/core';
import { LoginStatusService } from './login-status-service';
import { SignUpStatusService } from './signUp-status-service';
import { ITech } from './filterList';




@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  userLoginStatus:boolean = false;
  adminLoginStatus:boolean = false;
  mentorLoginStatus:boolean = false;
     _searchList : string;
     filteredList : ITech[];
     techList : ITech[] = [
  
    {
        "technologyName" : "Python",
        "duration" : 30,
        "timing" : "2-3",
        "fees" : 2500,
        "trainerName" : "Rahul"


    },
    {
      "technologyName" : "Spring Boot",
      "duration" : 20,
      "timing" : "2-3",
      "fees" : 1500,
      "trainerName" : "Naresh"


  },
  {
    "technologyName" : "Machine L",
    "duration" : 10,
    "timing" : "2-3",
    "fees" : 1200,
    "trainerName" : "Nishchay"


},
    {
        "technologyName" : "Spring",
        "duration" : 40,
        "timing" : "3-4",
        "fees" : 3500,
        "trainerName" : "Arushi"


    }
];


  
get searchList(): string {
return this._searchList;
}

set searchList(value : string) {
this._searchList = value;
this.filteredList = this.searchList ? this.performFilter(this.searchList) : this.techList;
}

performFilter( filterBy : string): ITech[] {
filterBy = filterBy.toLocaleLowerCase();
  return this.techList.filter((tech : ITech) => 
  tech.technologyName.toLocaleLowerCase().indexOf(filterBy) !== -1);

}

  
constructor(private loginStatusService : LoginStatusService , private signUpStatusService : SignUpStatusService ,){
  this.filteredList = this.techList;
    }
 
  fromLogin() {
    this.userLoginStatus = this.loginStatusService.getUserLoginStatus();
    this.adminLoginStatus = this.loginStatusService.getAdminLoginStatus();
    this.mentorLoginStatus = this.loginStatusService.getMentorLoginStatus();
   
  }

   
ngOnInit(): void {
 /* this.technologyService.getTechnology().subscribe( 
    technology => {
        this.technology = technology;
        
   },
   error => this.errorMessage = <any>error
);
this.technology = this.technology;
*/
}
 
 
   
   
 


}
