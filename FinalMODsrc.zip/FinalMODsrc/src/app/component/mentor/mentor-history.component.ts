import { Component, OnInit } from '@angular/core';
import { MentorService } from 'src/app/services/mentor-service';


@Component({
    selector: 'mentor-history',
    templateUrl: './mentor-history.component.html'
})
export class MentorHistoryComponent implements OnInit{
    public mentor;
    mentorId : number;
    mentorId1 : number = 11;
        constructor (private mentorService : MentorService){
    
        }
    
        ngOnInit(): void {
            this.getMentorHistory(this.mentorId1);
          }
        
          getMentorHistory(mentorId : number) {
              this.mentorService.getMentorHistory(mentorId).subscribe(
              data => { this.mentor = data},
              err =>console.log(this.mentor),
              
               );
              
                  
                  }
  
}