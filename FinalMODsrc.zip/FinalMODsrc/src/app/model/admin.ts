export class  Admin {
    adminId : number;
  userName : string;
  password : string;

}