import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'mentor-completed-training',
    templateUrl: './mcompleted-training.component.html'
})
export class McompletedTrainingComponent implements OnInit{
    ngOnInit(): void {
      
    }
  
}