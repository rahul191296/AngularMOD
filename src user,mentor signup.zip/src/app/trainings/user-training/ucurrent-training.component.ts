import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'user-current-training',
    templateUrl: './ucurrent-training.component.html'
})
export class UcurrentTrainingComponent implements OnInit{
    ngOnInit(): void {
      
    }
  
}